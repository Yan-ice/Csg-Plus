import org.bukkit.plugin.java.JavaPlugin;
import customgo.*;
import org.bukkit.entity.Player;
public class Temp { 
JavaPlugin plugin;
 public void _setPlugin(JavaPlugin p){plugin = p;}
Lobby lobby = null;Group group = null;Player striker = null;Player player = null;
public void _setMember(Lobby lobby,Group gro,Player striker,Player player){
this.group = gro; this.lobby=lobby;this.striker = striker;this.player = player;}

}