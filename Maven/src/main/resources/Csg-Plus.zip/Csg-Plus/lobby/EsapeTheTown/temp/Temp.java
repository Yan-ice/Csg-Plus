import org.bukkit.plugin.java.JavaPlugin;
import net.milkbowl.vault.economy.Economy;
import customgo.*;
import java.util.*;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.plugin.*;
import org.bukkit.entity.Player;
import me.clip.placeholderapi.PlaceholderAPI;
public class Temp { 
JavaPlugin plugin;
 public void _setPlugin(JavaPlugin p){plugin = p;}
Lobby lobby = null;Player striker = null;Player player = null;
public void _setMember(Lobby lobby, Player striker, Player player){
this.lobby=lobby;this.striker = striker;this.player = player;}

LobbyPlaceholder lobbyPlaceholderExp;
public void initPlaceholder(){
    lobbyPlaceholderExp = new LobbyPlaceholder(lobby);
    lobbyPlaceholderExp.register();
}

public void destroyPlaceholder(){
    lobbyPlaceholderExp.unregister();
}
public void addPlaceHolder(String k,String v){
    if(lobbyPlaceholderExp!=null){
        lobbyPlaceholderExp.addPlaceHolder(k,v);
    }else{
        System.out.println("尝试添加占位符，但并未成功连接到PAPI！");
    }
}

class LobbyPlaceholder extends PlaceholderExpansion{
	Lobby lobby;
	public LobbyPlaceholder(Lobby l) {
		lobby = l;
	}

    public void unregister(){
        PlaceholderAPI.unregisterPlaceholderHook(getIdentifier());    
    }
	public void addPlaceHolder(String key,String value){
		if(m.containsKey(key)){
			m.replace(key, value);
		}else{
			m.put(key, value);
		}
	}
	
	Map<String,String> m = new HashMap<>();
	
	@Override
	public String onPlaceholderRequest(Player arg0, String arg1) {
		for(String s : m.keySet()){
				if (arg1.equals(s)) {
					return m.get(s);
		        }
		}
		return "未知变量";
	}
	@Override
	public String getAuthor() {
		return "Yan_ice";
	}
	@Override
	public String getIdentifier() {
		return "fw"+lobby.getName();
	}
	@Override
	public String getVersion() {
		return "V1.1";
	}
	@Override
	public String getPlugin() {
		return "CustomGo";
	}

}

public boolean costEco(String arg){
    int cost = Integer.parseInt(arg);
    RegisteredServiceProvider<Economy> eco = plugin.getServer().getServicesManager().getRegistration(Economy.class);
	if (eco != null) {
		Economy economy = (eco.getProvider());
        if(economy!=null){
            if(player==null){
                System.out.println("错误：尝试扣除金币时目标为空！");
            }
            double count = economy.getBalance(player);
            if(count>=cost){
                economy.withdrawPlayer(player, cost);
                return true;
            }else{
                return false;
            }
        }else{
             System.out.println("错误：Vault服务未正常加载！");
        }
	}else{
        System.out.println("错误：无法找到Vault服务！");
    }
    
    return false;
}

public boolean checkEco(String arg){
    int cost = Integer.parseInt(arg);
    RegisteredServiceProvider<Economy> eco = plugin.getServer().getServicesManager().getRegistration(Economy.class);
	if (eco != null) {
		Economy economy = (eco.getProvider());
        if(economy!=null){
            if(player==null){
                System.out.println("错误：尝试检查金币时目标为空！");
            }
            double count = economy.getBalance(player);
            
            if(count>=cost){
                return true;
            }else{
                return false;
            }
        }else{
             System.out.println("错误：Vault服务未正常加载！");
        }
        
	}else{
        System.out.println("错误：无法找到Vault服务！");
    }
    
    return false;
}

public boolean checkArena(int x1,int x2,int z1,int z2){
    Location loc = player.getLocation();
    if(loc.x>x1 && loc.x<x2 && loc.z>z1 && loc.z<z2){
        return true;
    }
    return false;
}

List<EscapePoint> point_list = new ArrayList<>();

public void checkEscape(){
    for(EscapePoint p : point_list){
        if(p.isEnabled && checkArena(p.x1,p.x2,p.z1,p.z2)){
            if(extraCheck(p.name)){
                lobby.callFunction("startEscapeTimer",player,new Object[]{p.time});
                return;
            }
        }
    }
    lobby.PlayerValueBoard().Value("keep",0,player);
}

public void newPoint(String name,int x1,int x2,int z1, int z2, int time){
    EscapePoint p = new EscapePoint();
    p.x1 = x1;
    p.x2 = x2;
    p.z1 = z1;
    p.z2 = z2;
    p.time = time;
    p.name = name;
    point_list.add(p);
}

public void enablePoint(String name){
    String enabled = "";
    for(EscapePoint point : point_list){
        if(point.name.equals(name)){
            point.isEnabled = true;
        }
        if(point.isEnabled){
            enabled = enabled+point.name+" ";
        }
    }
    addPlaceHolder("enabled_point",enabled);
}

class EscapePoint{
    String name;
    int x1,x2,z1,z2;
    int time;
    boolean isEnabled = false;
}


public void initPoint(){
    //新加一个撤离点的格式：newPoint(名字,x1,x2,z1,z2, 撤离时间);
    newPoint("撤离点1",0,10,0,10, 30);
    newPoint("撤离点2",20,30,-20,-10, 20);
    newPoint("撤离点3",100,101,10,100, 20);
}

public boolean extraCheck(String name){
    if(name.equals("撤离点2")){
        //撤离点2要求玩家有30金币才能撤离。
        if(!checkEco("30")){
            return false;
        }
    }

    return true;
}
}