import org.bukkit.plugin.java.JavaPlugin;
import net.milkbowl.vault.economy.Economy;
import customgo.*;
import java.util.*;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.plugin.*;
import org.bukkit.entity.Player;
import me.clip.placeholderapi.PlaceholderAPI;
public class Temp { 
JavaPlugin plugin;
 public void _setPlugin(JavaPlugin p){plugin = p;}
Lobby lobby = null;Player striker = null;Player player = null;
public void _setMember(Lobby lobby, Player striker, Player player){
this.lobby=lobby;this.striker = striker;this.player = player;}

LobbyPlaceholder lobbyPlaceholderExp;
public void initPlaceholder(){
    lobbyPlaceholderExp = new LobbyPlaceholder(lobby);
    boolean success = lobbyPlaceholderExp.register();
	if(success){
		System.out.println("PAPI连接成功！");
	}else{
		System.out.println("PAPI连接失败！");
	}
}

public String replaceHolder(String s){
	return PlaceholderAPI.setPlaceholders(player,s);
}
public void destroyPlaceholder(){
    lobbyPlaceholderExp.p_unregister();
}
public void addPlaceHolder(String k,String v){
    if(lobbyPlaceholderExp!=null){
        lobbyPlaceholderExp.addPlaceHolder(k,v);
    }else{
        System.out.println("尝试添加占位符，但并未成功连接到PAPI！");
    }
}

class LobbyPlaceholder extends PlaceholderExpansion{
	Lobby lobby;
	public LobbyPlaceholder(Lobby l) {
		lobby = l;
	}

    public void p_unregister(){
        PlaceholderAPI.unregisterPlaceholderHook(getIdentifier());    
    }
	public void addPlaceHolder(String key,String value){
		if(m.containsKey(key)){
			m.replace(key, value);
		}else{
			m.put(key, value);
		}
	}
	
	Map<String,String> m = new HashMap<>();
	
	@Override
	public String onPlaceholderRequest(Player arg0, String arg1) {
		for(String s : m.keySet()){
				if (arg1.equals(s)) {
					return m.get(s);
		        }
		}
		return "未知变量";
	}
	@Override
	public String getAuthor() {
		return "Yan_ice";
	}
	@Override
	public String getIdentifier() {
		return "fw"+lobby.getName();
	}
	@Override
	public String getVersion() {
		return "V1.1";
	}
	@Override
	public String getPlugin() {
		return "Csg-Plus";
	}

}

LobbyPlaceholder lobbyPlaceholderExp;
public void initPlaceholder(){
    lobbyPlaceholderExp = new LobbyPlaceholder(lobby);
    boolean success = lobbyPlaceholderExp.register();
	if(success){
		System.out.println("PAPI连接成功！");
	}else{
		System.out.println("PAPI连接失败！");
	}
}

public void destroyPlaceholder(){
    lobbyPlaceholderExp.p_unregister();
}
public void addPlaceHolder(String k,String v){
    if(lobbyPlaceholderExp!=null){
        lobbyPlaceholderExp.addPlaceHolder(k,v);
    }else{
        System.out.println("尝试添加占位符，但并未成功连接到PAPI！");
    }
}

class LobbyPlaceholder extends PlaceholderExpansion{
	Lobby lobby;
	public LobbyPlaceholder(Lobby l) {
		lobby = l;
	}

    public void p_unregister(){
        PlaceholderAPI.unregisterPlaceholderHook(getIdentifier());    
    }
	public void addPlaceHolder(String key,String value){
		if(m.containsKey(key)){
			m.replace(key, value);
		}else{
			m.put(key, value);
		}
	}
	
	Map<String,String> m = new HashMap<>();
	
	@Override
	public String onPlaceholderRequest(Player arg0, String arg1) {
		for(String s : m.keySet()){
				if (arg1.equals(s)) {
					return m.get(s);
		        }
		}
		return "未知变量";
	}
	@Override
	public String getAuthor() {
		return "Yan_ice";
	}
	@Override
	public String getIdentifier() {
		return "fw"+lobby.getName();
	}
	@Override
	public String getVersion() {
		return "V1.1";
	}
	@Override
	public String getPlugin() {
		return "Csg-Plus";
	}

}

public boolean costEco(String arg){
    int cost = Integer.parseInt(arg);
    RegisteredServiceProvider<Economy> eco = plugin.getServer().getServicesManager().getRegistration(Economy.class);
	if (eco != null) {
		Economy economy = (eco.getProvider());
        if(economy!=null){
            if(player==null){
                System.out.println("错误：尝试扣除金币时目标为空！");
            }
            double count = economy.getBalance(player);
            if(count>=cost){
                economy.withdrawPlayer(player, cost);
                return true;
            }else{
                return false;
            }
        }else{
             System.out.println("错误：Vault服务未正常加载！");
        }
	}else{
        System.out.println("错误：无法找到Vault服务！");
    }
    
    return false;
}

public boolean checkEco(String arg){
    int cost = Integer.parseInt(arg);
    RegisteredServiceProvider<Economy> eco = plugin.getServer().getServicesManager().getRegistration(Economy.class);
	if (eco != null) {
		Economy economy = (eco.getProvider());
        if(economy!=null){
            if(player==null){
                System.out.println("错误：尝试检查金币时目标为空！");
            }
            double count = economy.getBalance(player);
            
            if(count>=cost){
                return true;
            }else{
                return false;
            }
        }else{
             System.out.println("错误：Vault服务未正常加载！");
        }
        
	}else{
        System.out.println("错误：无法找到Vault服务！");
    }
    
    return false;
}

public boolean costEco(String arg){
    int cost = Integer.parseInt(arg);
    RegisteredServiceProvider<Economy> eco = plugin.getServer().getServicesManager().getRegistration(Economy.class);
	if (eco != null) {
		Economy economy = (eco.getProvider());
        if(economy!=null){
            if(player==null){
                System.out.println("错误：尝试扣除金币时目标为空！");
            }
            double count = economy.getBalance(player);
            if(count>=cost){
                economy.withdrawPlayer(player, cost);
                return true;
            }else{
                return false;
            }
        }else{
             System.out.println("错误：Vault服务未正常加载！");
        }
	}else{
        System.out.println("错误：无法找到Vault服务！");
    }
    
    return false;
}

public boolean checkEco(String arg){
    int cost = Integer.parseInt(arg);
    RegisteredServiceProvider<Economy> eco = plugin.getServer().getServicesManager().getRegistration(Economy.class);
	if (eco != null) {
		Economy economy = (eco.getProvider());
        if(economy!=null){
            if(player==null){
                System.out.println("错误：尝试检查金币时目标为空！");
            }
            double count = economy.getBalance(player);
            
            if(count>=cost){
                return true;
            }else{
                return false;
            }
        }else{
             System.out.println("错误：Vault服务未正常加载！");
        }
        
	}else{
        System.out.println("错误：无法找到Vault服务！");
    }
    
    return false;
}
}